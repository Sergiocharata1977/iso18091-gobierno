# Design System Document: High-End Quality Management

## 1. Overview & Creative North Star

### Creative North Star: "The Architectural Ledger"
This design system moves beyond the generic "SaaS dashboard" aesthetic to embrace an editorial, high-precision visual language. For an ISO 9001 platform, the design must communicate more than just data; it must communicate **Authority, Traceability, and Intent**. 

We achieve this through "The Architectural Ledger" approach: a layout characterized by high-contrast typography scales, intentional asymmetry, and a rigorous adherence to tonal layering. By replacing rigid 1px borders with shifts in surface depth, we create an interface that feels like a series of interconnected, premium workspaces rather than a flat digital form. The result is a high-tech environment that feels curated, organized, and unmistakably professional.

---

## 2. Colors

The palette is a sophisticated evolution of corporate green and blue, utilizing deep, desaturated tones for grounding and vibrant containers for interaction.

### The "No-Line" Rule
Standard 1px solid borders for sectioning are strictly prohibited. Boundaries must be defined solely through background color shifts. For example, a card (using `surface_container_lowest`) sits on a workspace (using `surface_container_low`), which in turn sits on the global `background`. This creates a cleaner, more modern interface that relies on human perception of depth rather than artificial "ink" lines.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack.
- **Level 0 (Global):** `background` (#f8f9fa)
- **Level 1 (Sections):** `surface_container_low` (#f3f4f5)
- **Level 2 (Cards/Interaction):** `surface_container_lowest` (#ffffff)
- **Level 3 (Pop-overs/Modals):** `surface_bright` (#f8f9fa)

### The Glass & Gradient Rule
To provide "visual soul," primary CTAs and header elements should utilize a subtle linear gradient transitioning from `primary` (#003e35) to `primary_container` (#00574c). For floating utility elements (like top bars or navigation overlays), use Glassmorphism: apply `surface` colors at 80% opacity with a `20px` backdrop-blur to allow underlying content to bleed through softly.

---

## 3. Typography

The typography system uses **Inter** to bridge the gap between technical precision and modern readability.

*   **Display (lg/md/sm):** Used for high-impact data points or dashboard summaries. These are the "hero" numbers that signify health and compliance.
*   **Headline (lg/md/sm):** Used for page titles and major section headers. Use `on_surface` (#191c1d) with tight letter-spacing (-0.02em) to create a bold, authoritative editorial feel.
*   **Title (lg/md/sm):** The "Workhorse" of the system. Used for card titles and module headers.
*   **Body (lg/md/sm):** Optimized for long-form documentation and audit trails. Always ensure `body-md` is the default for readability.
*   **Labels (md/sm):** All-caps or high-weight small text for metadata, ISO clause references, and status tags.

---

## 4. Elevation & Depth

In this design system, elevation is a product of light and material, not structure.

### The Layering Principle
Depth is achieved by "stacking" the surface-container tiers. A `surface_container_highest` element should never sit directly on a `background` without an intermediate transition. This creates a natural, tactile "lift."

### Ambient Shadows
When a component must "float" (e.g., an active Modal or a hovering Card), use extra-diffused shadows.
- **Value:** `0px 12px 32px rgba(25, 28, 29, 0.06)`
- **Note:** The shadow color is a tinted version of `on_surface`, not a neutral grey. This mimics natural light passing through high-quality glass.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., Input Fields), use the **Ghost Border**: the `outline_variant` token (#c3c6d4) at 20% opacity. 100% opaque borders are forbidden as they "choke" the layout.

---

## 5. Components

### Buttons
*   **Primary:** Gradient of `primary` to `primary_container`. Roundedness: `md` (0.375rem). Use `on_primary` text.
*   **Secondary:** `secondary_container` background with `on_secondary_container` text. Subtle and sophisticated.
*   **Tertiary:** Transparent background, `primary` text. Use for low-priority actions like "Cancel."

### Input Fields
Avoid the "boxed" look. Use a `surface_container_low` background with a bottom-only `outline` for a refined, ledger-like appearance. Error states use `error` (#ba1a1a) for text and a `error_container` tint for the background.

### Cards & Lists
*   **Forbid dividers.** Use `spacing-6` (1.5rem) to separate list items or use alternating tonal shifts (`surface_container_low` vs `surface_container_lowest`).
*   **Contextual Chips:** Use `secondary_fixed` for status indicators (e.g., "In Progress") and `primary_fixed` for "Compliant" states.

### Sidebar (The Navigation Ledger)
The sidebar should use `inverse_surface` (#2e3132) or a deep `tertiary_container`. It must feel like a separate, grounded pillar of the application. Icons should be monochrome `on_surface_variant`, shifting to `primary_fixed` when active.

### Additional ISO-Specific Components
*   **The Audit Timeline:** A vertical layout using `surface_variant` nodes and `spacing-10` gaps.
*   **Clause Badges:** Small, high-contrast labels (`label-sm`) using `tertiary` colors to denote specific ISO 9001 clauses.

---

## 6. Do's and Don'ts

### Do's
*   **DO** use white space as a structural element. If a section feels cluttered, increase the spacing from `8` (2rem) to `12` (3rem).
*   **DO** use typography size to signify importance. A `display-sm` number is more effective than a bright red box.
*   **DO** align elements to a 4px baseline grid to maintain the "Architectural" feel.

### Don'ts
*   **DON'T** use 1px black or dark grey borders. It breaks the premium "frosted glass" aesthetic.
*   **DON'T** use standard drop shadows. If it looks like a "box shadow" from 2010, it’s too heavy.
*   **DON'T** crowd the Sidebar. Use the `spacing-scale` to provide breathing room between navigation categories.
*   **DON'T** mix different roundedness values in the same container. If a card is `lg`, its internal buttons should be `md` or `sm`.